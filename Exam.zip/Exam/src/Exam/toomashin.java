package Exam;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import javax.swing.SwingConstants;

public class toomashin {

	private JFrame frame1;
	private JTextField txtDisplay;
	private JPanel panel;
	private JPanel panel_1;
	private JButton btnOne;
	private JButton btnTwo;
	private JButton btnThree;
	private JButton btnFour;
	private JButton btnFive;
	private JButton btnSix;
	private JButton btnSeven;
	private JButton btnEight;
	private JButton btnNine;
	private JButton btnZero;
	private JButton btnPoint;
	private double total1 = 0.0;
	private double total2 = 0.0;
	private char math_operator;
	/**
	 * Create the application.
	 */
	public toomashin() {
		initialize();
	}

	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					toomashin window = new toomashin();
					window.frame1.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/*
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame1 = new JFrame();
		frame1.setBounds(100, 100, 409, 300);
		frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JPanel panel = new JPanel();
		frame1.getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		txtDisplay = new JTextField();
		txtDisplay.setHorizontalAlignment(SwingConstants.RIGHT);
		txtDisplay.setBounds(22, 11, 290, 37);
		panel.add(txtDisplay);
		txtDisplay.setColumns(10);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(90, 59, 199, 188);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		final JButton btnOne = new JButton("1");
		btnOne.setFont(new Font("Times New Roman", Font.BOLD, 10));
		btnOne.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String btnOneText = txtDisplay.getText() + btnOne.getText();
				txtDisplay.setText( btnOneText );
			}
		});
		btnOne.setBounds(10, 3, 39, 38);
		panel_1.add(btnOne);
		
		final JButton btnThree = new JButton("3");
		btnThree.setFont(new Font("Times New Roman", Font.BOLD, 10));
		btnThree.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String btnThreeText = txtDisplay.getText() + btnThree.getText();
				txtDisplay.setText( btnThreeText );
			}
		});
		btnThree.setBounds(108, 3, 39, 38);
		panel_1.add(btnThree);
		
		final JButton btnTwo = new JButton("2");
		btnTwo.setFont(new Font("Times New Roman", Font.BOLD, 10));
		btnTwo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String btnTwoText = txtDisplay.getText() + btnTwo.getText();
				txtDisplay.setText( btnTwoText );
			}
		});
		btnTwo.setBounds(59, 3, 39, 38);
		panel_1.add(btnTwo);
		
		final JButton btnFour = new JButton("4");
		btnFour.setFont(new Font("Times New Roman", Font.BOLD, 10));
		btnFour.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String btnFourText = txtDisplay.getText() + btnFour.getText();
				txtDisplay.setText( btnFourText );
			}
		});
		btnFour.setBounds(10, 52, 39, 38);
		panel_1.add(btnFour);
		
		final JButton btnSix = new JButton("6");
		btnSix.setFont(new Font("Times New Roman", Font.BOLD, 10));
		btnSix.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String btnSixText = txtDisplay.getText() + btnSix.getText();
				txtDisplay.setText( btnSixText );
			}
		});
		btnSix.setBounds(108, 52, 39, 38);
		panel_1.add(btnSix);
		
		final JButton btnFive = new JButton("5");
		btnFive.setFont(new Font("Times New Roman", Font.BOLD, 10));
		btnFive.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String btnFiveText = txtDisplay.getText() + btnFive.getText();
				txtDisplay.setText( btnFiveText );
			}
		});
		btnFive.setBounds(59, 52, 39, 38);
		panel_1.add(btnFive);
		
		final JButton btnSeven = new JButton("7");
		btnSeven.setFont(new Font("Times New Roman", Font.BOLD, 10));
		btnSeven.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String btnSevenText = txtDisplay.getText() + btnSeven.getText();
				txtDisplay.setText( btnSevenText );
			}
		});
		btnSeven.setBounds(10, 101, 39, 38);
		panel_1.add(btnSeven);
		
		final JButton btnNine = new JButton("9");
		btnNine.setFont(new Font("Times New Roman", Font.BOLD, 10));
		btnNine.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String btnNineText = txtDisplay.getText() + btnNine.getText();
				txtDisplay.setText( btnNineText );
			}
		});
		btnNine.setBounds(108, 101, 39, 38);
		panel_1.add(btnNine);
		
		final JButton btnEight = new JButton("8");
		btnEight.setFont(new Font("Times New Roman", Font.BOLD, 10));
		btnEight.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String btnEightText = txtDisplay.getText() + btnEight.getText();
				txtDisplay.setText( btnEightText );
			}
		});
		btnEight.setBounds(59, 101, 39, 38);
		panel_1.add(btnEight);
		
		final JButton btnZero = new JButton("0");
		btnZero.setFont(new Font("Times New Roman", Font.BOLD, 10));
		btnZero.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String btnZeroText = txtDisplay.getText() + btnZero.getText();
				txtDisplay.setText( btnZeroText );
			}
		});
		btnZero.setBounds(10, 144, 39, 38);
		panel_1.add(btnZero);
		
		JButton btnEquals = new JButton("=");
		btnEquals.setFont(new Font("Times New Roman", Font.BOLD, 8));
		btnEquals.setBounds(108, 144, 39, 38);
		panel_1.add(btnEquals);
		
		final JButton btnPlus = new JButton("+");
		btnPlus.setFont(new Font("Times New Roman", Font.BOLD, 8));
		btnPlus.setBounds(157, 3, 39, 38);
		panel_1.add(btnPlus);
		
		final JButton btnMinus = new JButton("-");
		btnMinus.setFont(new Font("Times New Roman", Font.BOLD, 10));
		btnMinus.setBounds(157, 52, 39, 38);
		panel_1.add(btnMinus);
		
		final JButton btnMultiply = new JButton("*");
		btnMultiply.setFont(new Font("Times New Roman", Font.BOLD, 10));
		btnMultiply.setBounds(157, 101, 39, 38);
		panel_1.add(btnMultiply);
		
		final JButton btnDivide = new JButton("/");
		btnDivide.setFont(new Font("Times New Roman", Font.BOLD, 10));
		btnDivide.setBounds(157, 144, 39, 37);
		panel_1.add(btnDivide);
		
		final JButton btnPoint = new JButton(".");
		btnPoint.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String btnPointText = txtDisplay.getText() + btnPoint.getText();
				txtDisplay.setText("0"+ btnPointText );
			}
		});
		btnPoint.setFont(new Font("Times New Roman", Font.BOLD, 10));
		btnPoint.setBounds(59, 144, 39, 38);
		panel_1.add(btnPoint);
		btnDivide.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String button_text = btnDivide.getText();
				getOperator(button_text);
			}
		});
		btnMultiply.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String button_text = btnMultiply.getText();
				getOperator(button_text);	
			}
		});
		btnMinus.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String button_text = btnMinus.getText();
				getOperator(button_text);
			}
		});
		btnPlus.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Double.parseDouble( txtDisplay.getText( ) );
				String button_text = btnPlus.getText();
				getOperator(button_text);
			}
		});
		btnEquals.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				switch ( math_operator ) {
				case '+':
					total2 = total1 + Double.parseDouble(txtDisplay.getText( ) );
				break;
				case '-':
					total2 = total1 - Double.parseDouble(txtDisplay.getText( ) );
				break;
				case '/':
					total2 = total1 / Double.parseDouble(txtDisplay.getText( ) );
				break;
				case '*':
					total2 = total1 * Double.parseDouble(txtDisplay.getText( ) );
				break;
				}
				txtDisplay.setText( Double.toString(total2) );
				total1 = 0;
			}
		});
		
		JButton btnClear = new JButton("Clear");
		btnClear.setFont(new Font("Times New Roman", Font.BOLD, 10));
		btnClear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				total2 = 0;
				txtDisplay.setText("");
			}
		});
		btnClear.setBounds(322, 10, 58, 39);
		panel.add(btnClear);
	}

	public JPanel getPanel() {
		return panel;
	}

	public void setPanel(JPanel panel) {
		this.panel = panel;
	}

	public JPanel getPanel_1() {
		return panel_1;
	}

	public void setPanel_1(JPanel panel_1) {
		this.panel_1 = panel_1;
	}

	public JButton getBtnOne() {
		return btnOne;
	}

	public void setBtnOne(JButton btnOne) {
		this.btnOne = btnOne;
	}

	public JButton getBtnTwo() {
		return btnTwo;
	}

	public void setBtnTwo(JButton btnTwo) {
		this.btnTwo = btnTwo;
	}

	public JButton getBtnThree() {
		return btnThree;
	}

	public void setBtnThree(JButton btnThree) {
		this.btnThree = btnThree;
	}

	public JButton getBtnFour() {
		return btnFour;
	}

	public void setBtnFour(JButton btnFour) {
		this.btnFour = btnFour;
	}

	public JButton getBtnFive() {
		return btnFive;
	}

	public void setBtnFive(JButton btnFive) {
		this.btnFive = btnFive;
	}

	public JButton getBtnSix() {
		return btnSix;
	}

	public void setBtnSix(JButton btnSix) {
		this.btnSix = btnSix;
	}

	public JButton getBtnEight() {
		return btnEight;
	}

	public void setBtnEight(JButton btnEight) {
		this.btnEight = btnEight;
	}

	public JButton getBtnSeven() {
		return btnSeven;
	}

	public void setBtnSeven(JButton btnSeven) {
		this.btnSeven = btnSeven;
	}

	public JButton getBtnNine() {
		return btnNine;
	}

	public void setBtnNine(JButton btnNine) {
		this.btnNine = btnNine;
	}

	public JButton getBtnZero() {
		return btnZero;
	}

	public void setBtnZero(JButton btnZero) {
		this.btnZero = btnZero;
	}

	public double getTotal1() {
		return total1;
	}

	public void setTotal1(double total1) {
		this.total1 = total1;
	}

	public double getTotal2() {
		return total2;
	}

	public void setTotal2(double total2) {
		this.total2 = total2;
	}

	public char getMath_operator() {
		return math_operator;
	}

	public void getOperator(String btnText) {
		math_operator = btnText.charAt(0);
		total1 = total1+Double.parseDouble(txtDisplay.getText());
		txtDisplay.setText("");

		
	}

	public JButton getBtnPoint() {
		return btnPoint;
	}

	public void setBtnPoint(JButton btnPoint) {
		this.btnPoint = btnPoint;
	}
	
}